Chức năng của admin:
	- Thêm, sửa, xóa các instance 
	(trừ instance Result chỉ có thể thêm khi 
	common user hoàn thành một Quiz_user được chỉ định).
	- Riêng với instance User, Quản trị viên chỉ có thể
	Thêm một thành viên với vai trò admin (set is_admin = 1)
	- Xem danh sách của mỗi loại instance.
	- Copy instance Question cho Quiz mới; 
	cũng như copy instance Answer cho Question mới
	- Giao exam cho common user (tạo một Quiz_user mới)


Chức năng của common user (is_admin == 0):
	- Xem danh sách các Quiz và các common User khác
	- làm bài thi được admin chỉ định (sẽ hiện thông báo trên 
	Dashboard)
	- Xem danh sách các bài thi đã làm và kết quả.
	- làm bài thi thử và xem kết quả