<?php

namespace App\Http\Actions;

class OnExamAction
{ }
