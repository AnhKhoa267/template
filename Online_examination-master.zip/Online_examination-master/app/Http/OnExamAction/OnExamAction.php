<?php

namespace App\Http\OnExamAction;

class OnExamAction
{
    //
}